<?php
ini_set('display_errors', 'Off');
session_start();
if (!isset($_SESSION['auth_key'])) {
    header("Location: index.php");
    exit();
}
$auth_key = $_SESSION['auth_key'];


$sistema_operacional = php_uname('s'); // Nome do sistema operacional
$versao_php = phpversion(); // Versão do PHP
$versao_apache = apache_get_version(); // Versão do Apache (se disponível)

// Obter o IP do servidor
$ip_servidor = $_SERVER['SERVER_ADDR'];

// Usar ipinfo.io para obter informações sobre a localização do IP do servidor
$dados_ip = file_get_contents('https://ipinfo.io/' . $ip_servidor . '/json');
$dados_ip_array = json_decode($dados_ip, true);

// Exibir informações sobre a localização do IP do servidor
$localizacao_servidor = isset($dados_ip_array['city']) ? $dados_ip_array['city'] . ', ' : '';
$localizacao_servidor .= isset($dados_ip_array['region']) ? $dados_ip_array['region'] . ', ' : '';
$localizacao_servidor .= isset($dados_ip_array['country']) ? $dados_ip_array['country'] : '';

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>
        <title>Zanda</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description"/>
        <meta content="Coderthemes" name="author"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/index.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        
        <header id="topnav">
            
            <div class="navbar-custom">
                <div class="container-fluid">
                    <ul class="list-unstyled topnav-menu float-right mb-0">
                        <li class="dropdown notification-list">
						    <i onclick="enviarRequisicao('bloquear_pc')" style="font-size: 50px; cursor: pointer;" class="menu-icon space text-success dripicons-lock"></i></a>
							<i onclick="enviarRequisicao('desconectar_internet')" style="font-size: 50px; cursor: pointer;" class="menu-icon space text-success dripicons-wifi"></i></a>						
                            <i onclick="enviarRequisicao('reiniciar')" style="font-size: 50px; cursor: pointer;" class="menu-icon space text-success dripicons-clockwise"></i>
							<i id="shutdownIcon" onclick="enviarRequisicao('desligar')" style="font-size: 50px; cursor: pointer;" class="menu-icon space text-success dripicons-power"></i>
                        </li>
                        <li class="dropdown notification-list">
						</li>
                    </ul>
                    <ul class="list-unstyled menu-left mb-0">
                        <li class="float-left logo-box">
						<div id="notificationPopup" class="notification-popup"></div>
						
                            <a href="logout.php"> <b href="s" class="menu-icon border-success text-success font-weight-bolder text-center w-auto" style="font-size: 3rem;">Zanda</b><a class="dripicons-exit"></a></a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="topbar-menu">
                <div class="container-fluid">
                    <div id="navigation">
                        
                        <div class="clearfix"></div>
                    </div>
                    
                </div>
                
            </div>
        </header>
        <div class="wrapper">
		<div style="margin-bottom: 20px;"></div>
            <div class="container-fluid">
                
                <div class="page-title-box">
                    <div class="page-title-right">
                    </div>
                    <h6 class="page-title">Informações do sistema</h6>
					
						<ul>
							<li><strong>Sistema Operacional:</strong> <?php echo $sistema_operacional; ?></li>
							<li><strong>Versão do PHP:</strong> <?php echo $versao_php; ?></li>
							<li><strong>Versão do Apache:</strong> <?php echo $versao_apache; ?></li>
							<li><strong>IP do Servidor:</strong> <?php echo $ip_servidor; ?></li>
							<li><strong>Localização do Servidor:</strong> <?php echo $localizacao_servidor; ?></li>
						</ul>
                </div>
            </div>    
        </div>
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 text-center">
                        2018 - 2019 &copy; Greeva theme by 
                        <a href="">Coderthemes</a> 
                    </div>
                </div>
            </div>
        </footer>
        </div>
        <div class="rightbar-overlay"></div>
        <script src="assets/js/ban.min.js"></script>
    </body>
