<?php
// Iniciar ou retomar a sessão
session_start();

// Definir um número máximo de tentativas de login permitidas
$maxTentativas = 3;

// Verificar se o usuário já excedeu o número máximo de tentativas de login
if (isset($_SESSION['tentativas']) && $_SESSION['tentativas'] >= $maxTentativas) {
    die("Você excedeu o número máximo de tentativas de login. Tente novamente mais tarde.");
}

// Gerar um token CSRF se não estiver definido
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Definir as chaves de autenticação
$auth_keys = array(
    '123' => true,
    'SUA-SENHA-AQUI' => true
);

// Definir tempo máximo de inatividade da sessão (em segundos)
$tempoMaximoInatividade = 1800; // 30 minutos

// Verificar se a sessão já foi iniciada anteriormente
if (isset($_SESSION['ultimo_acesso'])) {
    // Verificar se a sessão expirou devido ao tempo de inatividade
    if (time() - $_SESSION['ultimo_acesso'] > $tempoMaximoInatividade) {
        // Se a sessão expirou, destrua a sessão e redirecione para a página de login
        session_unset(); // Limpa todas as variáveis de sessão
        session_destroy(); // Destrói a sessão
        header("Location: login.php"); // Redireciona para a página de login
        exit(); // Encerra o script
    }
}

// Sanitizar a entrada do usuário para a chave de autenticação
$auth_key = isset($_POST['auth_key']) ? htmlspecialchars($_POST['auth_key']) : '';

// Verificar o token CSRF e processar o formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Erro: Token CSRF inválido.");
    }

    // Verificar se a chave de autenticação foi fornecida
    if (empty($auth_key)) {
        $_SESSION['login_status'] = "Por favor, preencha todos os campos.";
    } else {
        // Verificar a chave de autenticação
        if (!empty($auth_key) && isset($auth_keys[$auth_key])) {
            $_SESSION['auth_key'] = $auth_key;
            unset($_SESSION['tentativas']); // Limpar contagem de tentativas
            header("Location: painel.php");
            exit();
        } else {
            // Incrementar o número de tentativas de login
            if (!isset($_SESSION['tentativas'])) {
                $_SESSION['tentativas'] = 1;
            } else {
                $_SESSION['tentativas']++;
            }
            $_SESSION['ultimo_falha_login'] = time(); // Registrar o tempo da última falha de login
            $_SESSION['login_status'] = "Chave de autenticação inválida. Tentativas restantes: " . ($maxTentativas - $_SESSION['tentativas']);
        }
    }
}

// Atualizar o tempo do último acesso
$_SESSION['ultimo_acesso'] = time();
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>
        <title>Zanda</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="shortcut icon" href="assets/images/favicon.ico">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/index.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body class="authentication-bg d-flex align-items-center bg-light shadow-none">
        <div class="account-pages w-100 mt-5 mb-5">
            <div class="container">
                <div class="row justify-content-center border-primary no-gutters">
                    <div class="col-xl-5 col-lg-6 col-md-8 border border-success">
                        <div class="card">
                            <div class="card-body p-4 border-dark">
                                <div class="text-center mb-4">
                                    <a href="index.html"> <span></span> </a>
                                </div>
                                <p class="border-success ani-logo font-weight-bolder text-center w-auto"><span style="font-size: 7rem;">Zanda</span></p>
                                <p class="card-text"><span style="font-size: 0.9rem;">&nbsp;</span><br></p>
                                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="pt-2">
								<input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                                    <div class="form-group mb-3 text-left">
									<?php
									if (isset($_SESSION['login_status'])) {
										?>
										<div class="alert alert-danger alert-dismissible bg-danger text-white border-0 fade show text-center" role="alert">
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">×</span>
											</button>
											<?php echo htmlspecialchars($_SESSION['login_status'], ENT_QUOTES, 'UTF-8'); ?>

										</div>
										<?php
										unset($_SESSION['login_status']);
									}
									?>

                                        <input class="form-control form-control-sm text-center" name="auth_key" type="password" id="auth_key" required="" placeholder="Chave">
                                    </div>
                                    <div class="form-group mb-3">
                                        <a href="pages-recoverpassword.html" class="text-muted float-right"></a>
                                    </div>
                                    <div class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input" id="checkbox-signin" checked="">
                                    </div>
                                    <div class="form-group mb-0 text-center">
                                        <button class="btn btn-success btn-block" type="submit">Login</button>
                                    </div>
                                </form>
                                <div class="row mt-3">
                                    <div class="col-12 text-center">
									</div>                                     
                                    
                                </div>
                                
                            </div>                             
                            
                        </div>
                        
                    </div>                     
                    
                </div>
                
            </div>
            
        </div>
    </body>
</html>